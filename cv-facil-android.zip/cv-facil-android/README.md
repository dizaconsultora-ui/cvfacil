# CV Fácil: cómo obtener tu APK (sin instalar nada)

1. Creá una cuenta gratis en https://github.com y un repositorio nuevo (botón "New"), por ejemplo `cv-facil`.
2. En el repositorio tocá "Add file → Upload files" y subí TODO el contenido de esta carpeta (`www`, `package.json`, `capacitor.config.json`).
3. La carpeta oculta `.github`: si no se sube arrastrándola, tocá "Add file → Create new file", escribí el nombre `.github/workflows/build-apk.yml` y pegá el contenido de ese archivo.
4. Hacé "Commit changes". Andá a la pestaña **Actions**: se arma sola (unos 5 a 8 minutos).
5. Cuando termine, entrá a esa ejecución y abajo en **Artifacts** descargá `CV-Facil-APK`. Descomprimí el zip y pasá `app-debug.apk` a tu celular.
6. Instalalo (Android te va a pedir permitir "instalar apps de origen desconocido").

## IA gratis
1. Entrá a https://aistudio.google.com/app/apikey con tu cuenta de Google y creá una clave (sin tarjeta).
2. En la app tocá "🔑 Configurar IA gratuita" y pegá la clave. Queda guardada solo en tu celular.
3. Si Google cambia el nombre del modelo, podés cambiarlo en el segundo cuadro (por defecto: gemini-2.5-flash).
Nota: en el plan gratis Google puede usar los textos enviados para mejorar sus productos.
